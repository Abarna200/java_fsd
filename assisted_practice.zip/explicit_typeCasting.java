package assist_practice;

public class explicit_typeCasting {
	public static void main(String [] args) {
		
		double a= 98.99;
		
		int b=(int) a;  
		
		System.out.println("Converted Double "+a+" to int "+b);
		
	}

}

