package assist_practice;

public class implicit_typeCasting {
public static void main(String[] args) {
		
	    char a='S';
		
		System.out.println("Char "+a);
		
		int b=a;
		System.out.println("Char to int Conversion: "+b);
		
		
}

}
