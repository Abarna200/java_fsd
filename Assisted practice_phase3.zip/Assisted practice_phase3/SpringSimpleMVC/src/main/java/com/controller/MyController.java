package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller    //this is like servlet
public class MyController {
	
	@RequestMapping(value="hello", method=RequestMethod.GET)
	public ModelAndView sayHello() {
		ModelAndView mav=new ModelAndView();
		System.out.println("Hello there..");
		mav.setViewName("display.jsp");
		return mav;
	}
	
	@RequestMapping(value="hi", method=RequestMethod.GET)
	public ModelAndView sayHi() {
		ModelAndView mav=new ModelAndView();
		System.out.println("Hello there..");
		mav.setViewName("display1.jsp");
		return mav;
	}
}
