package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
public class DemoTest {
	public static void main(String[] args) {
			
		Resource rs= new ClassPathResource("beans.xml");
		BeanFactory bb=new XmlBeanFactory(rs);
			
		Address add1=new Address();
		System.out.println(add1);
		
		Employee employee8=(Employee)bb.getBean("emp8");
		System.out.println(employee8);
	}
