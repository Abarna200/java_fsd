package com.service;

public class OperationClass {
	public int add(int a, int b) {
		int add=a+b;
		return add;
	}
	
	public int sub(int a, int b) {
		int add=a-b;
		return add;
	}
	
	public int mul(int a, int b) {
		int add=a*b;
		return add;
	}
	
	public int div(int a, int b) {
		int add=a/b;
		return add;
	}
}
