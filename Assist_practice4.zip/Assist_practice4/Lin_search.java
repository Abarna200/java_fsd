package assist_practice4;
import java.util.Scanner;
public class Lin_search {
		public static void main(String[] args) {
			int[] a= {10,20,30,40,50};
			Scanner input= new Scanner(System.in);
			System.out.println("Enter the Element to  be Searched");
			int searchnumber= input.nextInt();
			int result= linearmethod(a,searchnumber);
			if(result==-1) 
			{
				System.out.println("Element Not Found In The Array");
			}
			else 
			{
				System.out.println("Element Found at the Array index: ["+result+"]\nThe number searched is : "+a[result]);
			}
			input.close();
			
		}
		
		public static int linearmethod(int[] arr,int searchValue) { 		
			for(int i=0; i<arr.length; i++) {
				if(arr[i]==searchValue) {
					return i;
				}
			}
			return -1;
		}
}

