package assist_practice4;
import java.util.Scanner;
public class Bin_search {
		public static void main(String[] args) 
		{
			int[] ar1 = {3,6,9,12,15};
	        int number;
	        int arrlength = ar1.length;
	        Scanner sc=new Scanner(System.in);
	        System.out.println("Enter the number to search in the array");
	        number=sc.nextInt();
	        binsearch(ar1,0,number,arrlength);		
	        sc.close();
		}

		public static void binsearch(int[] arr, int lb, int number, int ub) {
			
			int midValue= (lb+ub)/2;
			
			while(lb<=ub) {
				
				if(arr[midValue]<number)
				{
					lb= midValue+1;
				}
				else if(arr[midValue]==number)
				{
					System.out.println("Element found at index: "+midValue);
					break;
				}
				else {
					ub=midValue-1;
				}
				midValue=(lb+ub)/2;
			}
			if(lb>ub) {
				System.out.println("Element Not Found");
			}
			
		}

	}

