package assist_practice2;
class car
	{ 
	    public int gear; 
	    public int speed; 
	    public car(int gear, int speed) 
	    { 
	        this.gear = gear; 
	        this.speed = speed; 
	    } 
	    public void applyBrake(int decrement) 
	    { 
	        speed -= decrement; 
	    } 
	    public void speedUp(int increment) 
	    { 
	        speed += increment; 
	    }  
	    public String toString()  
	    { 
	        return("No of gears are " + gear + "\n" + "speed of car is " + speed); 
	    }  
	} 
	class skoda extends car  
	{ 
	    public String Colour ; 
	    public skoda(int gear,int speed,String carColour) 
	    {  
	        super(gear, speed); 
	        Colour  = carColour; 
	    }  
	    public void colour(String newValue) 
	    { 
	        Colour = newValue; 
	    } 
	    @Override
	    public String toString() 
	    { 
	        return (super.toString()+ 
	                "\ncolour is "+Colour ); 
	    } 
	}
	public class InheretTest  
	{ 
	    public static void main(String args[])  
	    { 
	    	skoda mb = new skoda(3, 100, "red"); 
	        System.out.println(mb.toString());
	    } 

}