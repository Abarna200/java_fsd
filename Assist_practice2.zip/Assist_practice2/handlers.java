package assist_practice2;
@SuppressWarnings("serial")
class handling extends Exception{
	   String str1;
	   handling(String str2) {
		str1=str2;
	   }
	   public String tostring(){ 
		return ("MyException Occurred: "+str1) ;
	   }
	}
class handlers{
	   public static void main(String args[]){
		try{
			System.out.println("Starting of try block");
			// I'm throwing the custom exception using throw
			throw new  handling("This is My error Message");
		}
		catch(handling exp){
			System.out.println("Catch Block") ;
			System.out.println(exp) ;
		}
	   }
	}

