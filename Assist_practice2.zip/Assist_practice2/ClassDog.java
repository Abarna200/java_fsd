package assist_practice2;

public class ClassDog {
	    String name; 
	    String breed; 
	    int age; 
	    String color; 
	    public ClassDog(String name, int age, String color) 
	    { 
	        this.name = name; 
	        this.age = age; 
	        this.color = color; 
	    } 
	    public String getName() 
	    { 
	        return name; 
	    } 
	    public int getAge() 
	    { 
	        return age; 
	    } 
	    public String getColor() 
	    { 
	        return color; 
	    } 
	    @Override
	    public String toString() 
	    { 
	        return("Hi my name is "+ this.getName()+ ".\nMy age and color are " + this.getAge()+ "and "+ this.getColor() + "."); 
	    } 
	    public static void main(String[] args) 
	    { 
	        ClassDog scotty = new ClassDog("Scotty", 5, "White"); 
	        System.out.println(scotty.toString()); 
	    } 
	}

