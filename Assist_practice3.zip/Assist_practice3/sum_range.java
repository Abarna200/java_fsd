package assist_practice3;
public class sum_range
{
	
	public static void main(String args[]) 
    { 
        int arr[] = { 4, 6, 3, 8, 5, 2 }; 
        int n = arr.length;

        sum_range.buildSparseTable(arr, n); 
        
        System.out.println(sum_range.query(0, 5)); 
        System.out.println(sum_range.query(3, 5)); 
        System.out.println(sum_range.query(2, 4)); 
    } 
	static int k = 16;
	static int N = 100000;
	
	static long tab[][] = new long[N][k + 1];

	static void buildSparseTable(int ar1[], int n) {
		
		for (int i = 0; i < n; i++)
			tab[i][0] = ar1[i];
		for (int j = 1; j <= k; j++)
			for (int i = 0; i <= n - (1 << j); i++)
				tab[i][j] = tab[i][j - 1] + tab[i + (1 << (j - 1))][j - 1];
	}

	static long query(int L, int R) {
		long result = 0;
		for (int j = k; j >= 0; j--) {
			if (L + (1 << j) - 1 <= R) {
				result= result + tab[L][j];
				L += 1 << j;
			}
		}
		return result;
	}
}

