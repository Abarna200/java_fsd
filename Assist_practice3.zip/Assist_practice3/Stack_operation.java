package assist_practice3;
public class Stack_operation 
{
		static final int MAX=1000;
		int  t;
		int arr[]= new int[MAX];
		
		boolean isEmpty() 
		{
			
			return t<0;
			
		}
		//constructor
		public Stack_operation() 
		{
			t=-1;
		}
		
		//add an element to stack
		boolean push(int a) 
		{
			if(t>=(MAX-1))
			{
				System.out.println("Stack is Overflow");
				return false;
			}
			else 
			{
				arr[++t]=a;
				System.out.println(a+" Pushed into stack");
				return true;
			}
		}
		
		//removal of elements
		int pop() 
		{
			
			if(t<0) 
			{
				System.out.println("Statck  is UNDERFLOW");
				return 0;
			}
			else 
			{
				int x= arr[t--];
				return x;
			}			
		}
		
		public static void main(String[] args) 
		{
			Stack_operation s1=  new Stack_operation();
			s1.push(10);
			s1.push(23);
			s1.push(35);
			s1.push(42);
			s1.push(50);
			
			System.out.println(s1.pop()+ " : Poped Out from stack");
		}
}


