package assist_practice3;
public class Matrix_multiply {
	
	public static void main(String[] args) {
		
		int r1=2, c1=3;
		int c2=2;
		
		int [][] FMat= {{9,-2,3},{5,0,4}};
		int [][] SMat= {{1,8},{-6,0},{0,7}};
		
		
		//to multiply the matrix
		
		int[][]  prod= multiplyMatrix(FMat,SMat,r1,c1,c2);
		
		//display the result of multiplication
		displayresult(prod);
	}
	
	private static int[][] multiplyMatrix(int[][] firstMatrix, int[][] secondMatrix,  int R1,  int C1,int C2)
	{
		
		int[][] result = new int[R1][C2];//  resultant matrix
		
		for(int i=0; i<R1;  i++) {
			
			for(int j=0; j<C2; j++) {
				
				for(int k=0;k<C1;  k++) {
					 result[i][j]+=firstMatrix[i][k]*secondMatrix[k][j];
				}
			}
			
		}
		return result;
	}
	
	private static void displayresult(int [][]product) {
		
		System.out.println("Product of two matrices is : ");
		for(int[] row: product) {
			
			for(int column:row) {
				System.out.print(column+ " ");
			}
			System.out.println();
		}
		
	}
}

