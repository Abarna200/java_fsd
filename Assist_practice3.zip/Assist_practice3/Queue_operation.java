package assist_practice3;
import java.util.LinkedList;
import java.util.Queue;

public class Queue_operation 
{
	
	public static void main(String[] args) {
		Queue<String> Queuelist= new LinkedList<String>();
		
		Queuelist.add("mike");
		Queuelist.add("max");
		Queuelist.add("jack");
		Queuelist.add("guen");
		
		System.out.println("Queue is : "+Queuelist);		
		//find head of queue
		System.out.println("Head of the Queue list : "+Queuelist.peek());
		Queuelist.remove();		
		System.out.println("After Removing Head: "+Queuelist);
		
	}

}



